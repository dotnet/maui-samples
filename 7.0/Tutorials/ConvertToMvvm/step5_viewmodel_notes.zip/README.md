# .NET MAUI - Upgrade to MVVM - Step 5

This folder contains the code a user has after completing the [Upgrade your app with MVVM concepts - Step 5](https://learn.microsoft.com/dotnet/maui/tutorials/notes-mvvm/?tutorial-step=5) tutorial.

[.zip download](../step5_viewmodel_notes.zip)
