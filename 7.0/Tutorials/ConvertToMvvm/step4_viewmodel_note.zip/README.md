# .NET MAUI - Upgrade to MVVM - Step 4

This folder contains the code a user has after completing the [Upgrade your app with MVVM concepts - Step 4](https://learn.microsoft.com/dotnet/maui/tutorials/notes-mvvm/?tutorial-step=4) tutorial.

[.zip download](../step4_viewmodel_note.zip)
