# .NET MAUI - Upgrade to MVVM - Step 3

This folder contains the code a user has after completing the [Upgrade your app with MVVM concepts - Step 3](https://learn.microsoft.com/dotnet/maui/tutorials/notes-mvvm/?tutorial-step=3) tutorial.

[.zip download](../step3_viewmodel_about.zip)
