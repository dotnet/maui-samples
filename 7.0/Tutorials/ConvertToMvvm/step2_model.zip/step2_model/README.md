# .NET MAUI - Upgrade to MVVM - Step 2

This folder contains the code a user has after completing the [Upgrade your app with MVVM concepts - Step 2](https://learn.microsoft.com/dotnet/maui/tutorials/notes-mvvm/?tutorial-step=2) tutorial.

[.zip download](../step2_model.zip)
