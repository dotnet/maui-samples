# .NET MAUI - Upgrade to MVVM - Step 1

This folder contains the code for the [Upgrade your app with MVVM concepts](https://learn.microsoft.com/en-us/dotnet/maui/tutorials/notes-mvvm/) tutorial, specifically the code you have after completing step 1.
