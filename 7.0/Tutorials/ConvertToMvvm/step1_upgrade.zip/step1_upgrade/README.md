# .NET MAUI - Upgrade to MVVM - Step 1

This folder contains the code a user has after completing the [Upgrade your app with MVVM concepts - Step 1](https://learn.microsoft.com/dotnet/maui/tutorials/notes-mvvm/?tutorial-step=1) tutorial.

[.zip download](../step1_upgrade.zip)
